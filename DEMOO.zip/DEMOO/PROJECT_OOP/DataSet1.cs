﻿namespace PROJECT_OOP
{
}

namespace PROJECT_OOP
{


    public partial class DataSet1
    {
    }
}
namespace PROJECT_OOP {
    
    
    public partial class DataSet1 {
    }
}
