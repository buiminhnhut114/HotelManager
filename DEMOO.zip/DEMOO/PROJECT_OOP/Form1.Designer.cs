﻿namespace PROJECT_OOP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btntkmaphong = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txthovaten = new System.Windows.Forms.TextBox();
            this.cbmaphong = new System.Windows.Forms.ComboBox();
            this.pHONGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new PROJECT_OOP.DataSet1();
            this.btntkhovaten = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbtongtien = new System.Windows.Forms.Label();
            this.lbsongayo = new System.Windows.Forms.Label();
            this.lbphong = new System.Windows.Forms.Label();
            this.btnthoat = new System.Windows.Forms.Button();
            this.btntinhtien = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelphong = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnxemtinhtrang = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbloaiphong = new System.Windows.Forms.ComboBox();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.datengaytraphong = new System.Windows.Forms.DateTimePicker();
            this.datengaynhanphong = new System.Windows.Forms.DateTimePicker();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btndatphong = new System.Windows.Forms.Button();
            this.txtcccd = new System.Windows.Forms.TextBox();
            this.txthoten = new System.Windows.Forms.TextBox();
            this.makh = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pHONGBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pHONGTableAdapter = new PROJECT_OOP.DataSet1TableAdapters.PHONGTableAdapter();
            this.khachhanG1TableAdapter1 = new PROJECT_OOP.DataSet1TableAdapters.KHACHHANG1TableAdapter();
            this.pHONGBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pHONGBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.khachhanG1TableAdapter2 = new PROJECT_OOP.DataSet1TableAdapters.KHACHHANG1TableAdapter();
            this.khachhanG1TableAdapter3 = new PROJECT_OOP.DataSet1TableAdapters.KHACHHANG1TableAdapter();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.khachhanG1TableAdapter4 = new PROJECT_OOP.DataSet1TableAdapters.KHACHHANG1TableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.khachhanG1TableAdapter5 = new PROJECT_OOP.DataSet1TableAdapters.KHACHHANG1TableAdapter();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtMaHoaDon = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBoxMaPhong = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.dateTimePickerNgayThanhToan = new System.Windows.Forms.DateTimePicker();
            this.btnthemhoadon = new System.Windows.Forms.Button();
            this.btnXoaa = new System.Windows.Forms.Button();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource3)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Phòng";
            // 
            // btntkmaphong
            // 
            this.btntkmaphong.Location = new System.Drawing.Point(426, 21);
            this.btntkmaphong.Name = "btntkmaphong";
            this.btntkmaphong.Size = new System.Drawing.Size(217, 39);
            this.btntkmaphong.TabIndex = 1;
            this.btntkmaphong.Text = "Tìm Kiếm Theo Mã Phòng";
            this.btntkmaphong.UseVisualStyleBackColor = true;
            this.btntkmaphong.Click += new System.EventHandler(this.btntkmaphong_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txthovaten);
            this.groupBox1.Controls.Add(this.cbmaphong);
            this.groupBox1.Controls.Add(this.btntkhovaten);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btntkmaphong);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 70);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(704, 127);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm Nhanh";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txthovaten
            // 
            this.txthovaten.Location = new System.Drawing.Point(112, 85);
            this.txthovaten.Name = "txthovaten";
            this.txthovaten.Size = new System.Drawing.Size(146, 22);
            this.txthovaten.TabIndex = 5;
            // 
            // cbmaphong
            // 
            this.cbmaphong.DataSource = this.pHONGBindingSource;
            this.cbmaphong.DisplayMember = "MaPhong";
            this.cbmaphong.FormattingEnabled = true;
            this.cbmaphong.Location = new System.Drawing.Point(112, 36);
            this.cbmaphong.Name = "cbmaphong";
            this.cbmaphong.Size = new System.Drawing.Size(121, 24);
            this.cbmaphong.TabIndex = 4;
            this.cbmaphong.SelectedIndexChanged += new System.EventHandler(this.cbmaphong_SelectedIndexChanged);
            // 
            // pHONGBindingSource
            // 
            this.pHONGBindingSource.DataMember = "PHONG";
            this.pHONGBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btntkhovaten
            // 
            this.btntkhovaten.Location = new System.Drawing.Point(426, 75);
            this.btntkhovaten.Name = "btntkhovaten";
            this.btntkhovaten.Size = new System.Drawing.Size(217, 37);
            this.btntkhovaten.TabIndex = 3;
            this.btntkhovaten.Text = "Tìm Kiếm Theo Họ và Tên";
            this.btntkhovaten.UseVisualStyleBackColor = true;
            this.btntkhovaten.Click += new System.EventHandler(this.btntkhovaten_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Họ và Tên";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbtongtien);
            this.groupBox2.Controls.Add(this.lbsongayo);
            this.groupBox2.Controls.Add(this.lbphong);
            this.groupBox2.Controls.Add(this.btnthoat);
            this.groupBox2.Controls.Add(this.btntinhtien);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.labelphong);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(8, 224);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(708, 129);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thanh Toán";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // lbtongtien
            // 
            this.lbtongtien.AutoSize = true;
            this.lbtongtien.Location = new System.Drawing.Point(200, 102);
            this.lbtongtien.Name = "lbtongtien";
            this.lbtongtien.Size = new System.Drawing.Size(0, 16);
            this.lbtongtien.TabIndex = 11;
            // 
            // lbsongayo
            // 
            this.lbsongayo.AutoSize = true;
            this.lbsongayo.Location = new System.Drawing.Point(174, 68);
            this.lbsongayo.Name = "lbsongayo";
            this.lbsongayo.Size = new System.Drawing.Size(0, 16);
            this.lbsongayo.TabIndex = 10;
            // 
            // lbphong
            // 
            this.lbphong.AutoSize = true;
            this.lbphong.Location = new System.Drawing.Point(164, 35);
            this.lbphong.Name = "lbphong";
            this.lbphong.Size = new System.Drawing.Size(0, 16);
            this.lbphong.TabIndex = 9;
            // 
            // btnthoat
            // 
            this.btnthoat.BackColor = System.Drawing.Color.LightSalmon;
            this.btnthoat.Location = new System.Drawing.Point(590, 5);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(77, 76);
            this.btnthoat.TabIndex = 6;
            this.btnthoat.Text = "Thoát";
            this.btnthoat.UseVisualStyleBackColor = false;
            this.btnthoat.Click += new System.EventHandler(this.btnthoat_Click);
            // 
            // btntinhtien
            // 
            this.btntinhtien.BackColor = System.Drawing.SystemColors.Info;
            this.btntinhtien.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btntinhtien.Location = new System.Drawing.Point(489, 5);
            this.btntinhtien.Name = "btntinhtien";
            this.btntinhtien.Size = new System.Drawing.Size(75, 76);
            this.btntinhtien.TabIndex = 6;
            this.btntinhtien.Text = "Tính Tiền";
            this.btntinhtien.UseVisualStyleBackColor = false;
            this.btntinhtien.Click += new System.EventHandler(this.btntinhtien_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tổng Tiền Phải Thanh Toán";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Số Ngày Khách Ở";
            // 
            // labelphong
            // 
            this.labelphong.AutoSize = true;
            this.labelphong.Location = new System.Drawing.Point(31, 35);
            this.labelphong.Name = "labelphong";
            this.labelphong.Size = new System.Drawing.Size(113, 16);
            this.labelphong.TabIndex = 6;
            this.labelphong.Text = "Phòng Khách Ở";
            this.labelphong.Click += new System.EventHandler(this.label3_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listView1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(12, 369);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(704, 226);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Chi Tiết Khách Hàng Thanh Toán";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(692, 201);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã KH";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Họ và Tên";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Số CCCD";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Ngày Đến";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 120;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Mã Phòng";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 120;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(734, 80);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(668, 522);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel5);
            this.tabPage1.Controls.Add(this.tableLayoutPanel4);
            this.tabPage1.Controls.Add(this.tableLayoutPanel3);
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Controls.Add(this.listView2);
            this.tabPage1.Controls.Add(this.btnxemtinhtrang);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(583, 493);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Xem Tình Trạng Phòng";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.DodgerBlue;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Location = new System.Drawing.Point(170, 104);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(262, 12);
            this.tableLayoutPanel5.TabIndex = 11;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.SkyBlue;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(15, 382);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.85714F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.14286F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(75, 44);
            this.tableLayoutPanel4.TabIndex = 13;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(15, 283);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.85714F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.14286F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(75, 39);
            this.tableLayoutPanel3.TabIndex = 12;
            this.tableLayoutPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel3_Paint);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.SandyBrown;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(15, 213);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.85714F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.14286F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(74, 38);
            this.tableLayoutPanel2.TabIndex = 11;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DarkRed;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(15, 119);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(75, 36);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7});
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(170, 119);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(262, 374);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Mã Phòng";
            this.columnHeader6.Width = 136;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Tình Trạng";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 144;
            // 
            // btnxemtinhtrang
            // 
            this.btnxemtinhtrang.Location = new System.Drawing.Point(187, 6);
            this.btnxemtinhtrang.Name = "btnxemtinhtrang";
            this.btnxemtinhtrang.Size = new System.Drawing.Size(215, 49);
            this.btnxemtinhtrang.TabIndex = 12;
            this.btnxemtinhtrang.Text = "Xem Tình Trạng";
            this.btnxemtinhtrang.UseVisualStyleBackColor = true;
            this.btnxemtinhtrang.Click += new System.EventHandler(this.btnxemtinhtrang_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(144, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 16);
            this.label13.TabIndex = 17;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 158);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 16);
            this.label12.TabIndex = 16;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(144, 85);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 16);
            this.label11.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 16);
            this.label10.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 345);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 16);
            this.label9.TabIndex = 13;
            this.label9.Text = "Đang Bảo Trì";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 264);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "Trống";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Có Khách";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Đã Đặt";
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cbloaiphong);
            this.tabPage2.Controls.Add(this.listView3);
            this.tabPage2.Controls.Add(this.datengaytraphong);
            this.tabPage2.Controls.Add(this.datengaynhanphong);
            this.tabPage2.Controls.Add(this.btnxoa);
            this.tabPage2.Controls.Add(this.btndatphong);
            this.tabPage2.Controls.Add(this.txtcccd);
            this.tabPage2.Controls.Add(this.txthoten);
            this.tabPage2.Controls.Add(this.makh);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(583, 493);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Đặt Phòng";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // cbloaiphong
            // 
            this.cbloaiphong.DataSource = this.pHONGBindingSource;
            this.cbloaiphong.DisplayMember = "SoGiuong";
            this.cbloaiphong.FormattingEnabled = true;
            this.cbloaiphong.Location = new System.Drawing.Point(154, 179);
            this.cbloaiphong.Name = "cbloaiphong";
            this.cbloaiphong.Size = new System.Drawing.Size(121, 24);
            this.cbloaiphong.TabIndex = 6;
            this.cbloaiphong.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // listView3
            // 
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader13,
            this.columnHeader14});
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(18, 274);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(556, 219);
            this.listView3.TabIndex = 20;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            this.listView3.SelectedIndexChanged += new System.EventHandler(this.listView3_SelectedIndexChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Mã KH";
            this.columnHeader8.Width = 90;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Họ và Tên";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 90;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Số CCCD";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 90;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Ngày Nhận Phòng";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 90;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Ngày Trả Phòng";
            this.columnHeader13.Width = 90;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Loại Phòng";
            this.columnHeader14.Width = 90;
            // 
            // datengaytraphong
            // 
            this.datengaytraphong.Location = new System.Drawing.Point(154, 145);
            this.datengaytraphong.Name = "datengaytraphong";
            this.datengaytraphong.Size = new System.Drawing.Size(278, 22);
            this.datengaytraphong.TabIndex = 19;
            // 
            // datengaynhanphong
            // 
            this.datengaynhanphong.Location = new System.Drawing.Point(154, 113);
            this.datengaynhanphong.Name = "datengaynhanphong";
            this.datengaynhanphong.Size = new System.Drawing.Size(278, 22);
            this.datengaynhanphong.TabIndex = 18;
            // 
            // btnxoa
            // 
            this.btnxoa.BackColor = System.Drawing.Color.LightBlue;
            this.btnxoa.Location = new System.Drawing.Point(328, 218);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(79, 48);
            this.btnxoa.TabIndex = 17;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = false;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btndatphong
            // 
            this.btndatphong.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btndatphong.ForeColor = System.Drawing.SystemColors.WindowText;
            this.btndatphong.Location = new System.Drawing.Point(154, 218);
            this.btndatphong.Name = "btndatphong";
            this.btndatphong.Size = new System.Drawing.Size(86, 48);
            this.btndatphong.TabIndex = 12;
            this.btndatphong.Text = " Đặt Phòng";
            this.btndatphong.UseVisualStyleBackColor = false;
            this.btndatphong.Click += new System.EventHandler(this.btndatphong_Click_1);
            // 
            // txtcccd
            // 
            this.txtcccd.Location = new System.Drawing.Point(135, 87);
            this.txtcccd.Name = "txtcccd";
            this.txtcccd.Size = new System.Drawing.Size(121, 22);
            this.txtcccd.TabIndex = 13;
            this.txtcccd.TextChanged += new System.EventHandler(this.txtcccd_TextChanged);
            // 
            // txthoten
            // 
            this.txthoten.Location = new System.Drawing.Point(135, 58);
            this.txthoten.Name = "txthoten";
            this.txthoten.Size = new System.Drawing.Size(121, 22);
            this.txthoten.TabIndex = 12;
            // 
            // makh
            // 
            this.makh.Location = new System.Drawing.Point(135, 31);
            this.makh.Name = "makh";
            this.makh.Size = new System.Drawing.Size(121, 22);
            this.makh.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 151);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(121, 16);
            this.label19.TabIndex = 11;
            this.label19.Text = "Ngày Trả Phòng";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 119);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(133, 16);
            this.label18.TabIndex = 6;
            this.label18.Text = "Ngày Nhận Phòng";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 87);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 16);
            this.label17.TabIndex = 10;
            this.label17.Text = "Số CCCD";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(21, 187);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 16);
            this.label16.TabIndex = 6;
            this.label16.Text = "Loại Phòng";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 61);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 16);
            this.label15.TabIndex = 8;
            this.label15.Text = "Họ và Tên";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "Mã KH";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // pHONGBindingSource2
            // 
            this.pHONGBindingSource2.DataMember = "PHONG";
            this.pHONGBindingSource2.DataSource = this.dataSet1BindingSource;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.dataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // pHONGTableAdapter
            // 
            this.pHONGTableAdapter.ClearBeforeFill = true;
            // 
            // khachhanG1TableAdapter1
            // 
            this.khachhanG1TableAdapter1.ClearBeforeFill = true;
            // 
            // pHONGBindingSource1
            // 
            this.pHONGBindingSource1.DataMember = "PHONG";
            this.pHONGBindingSource1.DataSource = this.dataSet1;
            // 
            // pHONGBindingSource3
            // 
            this.pHONGBindingSource3.DataMember = "PHONG";
            this.pHONGBindingSource3.DataSource = this.dataSet1;
            // 
            // khachhanG1TableAdapter2
            // 
            this.khachhanG1TableAdapter2.ClearBeforeFill = true;
            // 
            // khachhanG1TableAdapter3
            // 
            this.khachhanG1TableAdapter3.ClearBeforeFill = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // khachhanG1TableAdapter4
            // 
            this.khachhanG1TableAdapter4.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(0, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1336, 63);
            this.button1.TabIndex = 9;
            this.button1.Text = "QUẢN LÝ KHÁCH SẠN";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // khachhanG1TableAdapter5
            // 
            this.khachhanG1TableAdapter5.ClearBeforeFill = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listView4);
            this.tabPage3.Controls.Add(this.btnXoaa);
            this.tabPage3.Controls.Add(this.btnthemhoadon);
            this.tabPage3.Controls.Add(this.dateTimePickerNgayThanhToan);
            this.tabPage3.Controls.Add(this.txtTongTien);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.comboBoxMaPhong);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.txtMaKH);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.txtMaHoaDon);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(660, 493);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Quản Lý Hóa Đơn";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtMaHoaDon
            // 
            this.txtMaHoaDon.Location = new System.Drawing.Point(183, 21);
            this.txtMaHoaDon.Name = "txtMaHoaDon";
            this.txtMaHoaDon.Size = new System.Drawing.Size(146, 22);
            this.txtMaHoaDon.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(34, 53);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 16);
            this.label20.TabIndex = 6;
            this.label20.Text = "Mã KH";
            // 
            // txtMaKH
            // 
            this.txtMaKH.Location = new System.Drawing.Point(183, 50);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(146, 22);
            this.txtMaKH.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Mã Hóa Đơn";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(32, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(132, 16);
            this.label21.TabIndex = 9;
            this.label21.Text = "Ngày Thanh Toán";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(34, 140);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 16);
            this.label22.TabIndex = 6;
            this.label22.Text = "Mã Phòng";
            // 
            // comboBoxMaPhong
            // 
            this.comboBoxMaPhong.DataSource = this.pHONGBindingSource;
            this.comboBoxMaPhong.DisplayMember = "MaPhong";
            this.comboBoxMaPhong.FormattingEnabled = true;
            this.comboBoxMaPhong.Location = new System.Drawing.Point(183, 137);
            this.comboBoxMaPhong.Name = "comboBoxMaPhong";
            this.comboBoxMaPhong.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMaPhong.TabIndex = 6;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(32, 187);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 16);
            this.label23.TabIndex = 10;
            this.label23.Text = "Tổng Tiền";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(143, 184);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(173, 22);
            this.txtTongTien.TabIndex = 11;
            // 
            // dateTimePickerNgayThanhToan
            // 
            this.dateTimePickerNgayThanhToan.Location = new System.Drawing.Point(183, 88);
            this.dateTimePickerNgayThanhToan.Name = "dateTimePickerNgayThanhToan";
            this.dateTimePickerNgayThanhToan.Size = new System.Drawing.Size(278, 22);
            this.dateTimePickerNgayThanhToan.TabIndex = 21;
            // 
            // btnthemhoadon
            // 
            this.btnthemhoadon.Location = new System.Drawing.Point(35, 234);
            this.btnthemhoadon.Name = "btnthemhoadon";
            this.btnthemhoadon.Size = new System.Drawing.Size(129, 39);
            this.btnthemhoadon.TabIndex = 6;
            this.btnthemhoadon.Text = "Thêm Hóa Đơn";
            this.btnthemhoadon.UseVisualStyleBackColor = true;
            this.btnthemhoadon.Click += new System.EventHandler(this.btnthemhoadon_Click);
            // 
            // btnXoaa
            // 
            this.btnXoaa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoaa.Location = new System.Drawing.Point(231, 234);
            this.btnXoaa.Name = "btnXoaa";
            this.btnXoaa.Size = new System.Drawing.Size(129, 39);
            this.btnXoaa.TabIndex = 23;
            this.btnXoaa.Text = "Xóa";
            this.btnXoaa.UseVisualStyleBackColor = true;
            this.btnXoaa.Click += new System.EventHandler(this.btnXoaa_Click);
            // 
            // listView4
            // 
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18});
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(35, 283);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(545, 210);
            this.listView4.TabIndex = 21;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Mã Hóa Đơn";
            this.columnHeader12.Width = 103;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Ngày Thanh Toán";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 148;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Tổng Tiền";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 90;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Mã Phòng";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader17.Width = 135;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Mã KH";
            this.columnHeader18.Width = 188;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1334, 614);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.Form1_Click);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHONGBindingSource3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btntkmaphong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txthovaten;
        private System.Windows.Forms.ComboBox cbmaphong;
        private System.Windows.Forms.Button btntkhovaten;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.Button btntinhtien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelphong;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView listView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource pHONGBindingSource;
        private DataSet1TableAdapters.PHONGTableAdapter pHONGTableAdapter;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Label lbtongtien;
        private System.Windows.Forms.Label lbsongayo;
        private System.Windows.Forms.Label lbphong;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private DataSet1TableAdapters.KHACHHANG1TableAdapter khachhanG1TableAdapter1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button btnxemtinhtrang;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker datengaytraphong;
        private System.Windows.Forms.DateTimePicker datengaynhanphong;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btndatphong;
        private System.Windows.Forms.TextBox txtcccd;
        private System.Windows.Forms.TextBox txthoten;
        private System.Windows.Forms.TextBox makh;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.BindingSource pHONGBindingSource1;
        private System.Windows.Forms.BindingSource pHONGBindingSource2;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private System.Windows.Forms.ComboBox cbloaiphong;
        private System.Windows.Forms.BindingSource pHONGBindingSource3;
        private DataSet1TableAdapters.KHACHHANG1TableAdapter khachhanG1TableAdapter2;
        private DataSet1TableAdapters.KHACHHANG1TableAdapter khachhanG1TableAdapter3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private DataSet1TableAdapters.KHACHHANG1TableAdapter khachhanG1TableAdapter4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DataSet1TableAdapters.KHACHHANG1TableAdapter khachhanG1TableAdapter5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnXoaa;
        private System.Windows.Forms.Button btnthemhoadon;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayThanhToan;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBoxMaPhong;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtMaHoaDon;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
    }
}

